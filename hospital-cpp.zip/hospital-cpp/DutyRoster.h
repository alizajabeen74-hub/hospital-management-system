#ifndef DUTYROSTER_H
#define DUTYROSTER_H

#include <string>
#include <vector>
#include <map>

// ─────────────────────────────────────────────
//  Shift types
// ─────────────────────────────────────────────
enum class Shift { MORNING, EVENING, NIGHT };

std::string shiftToString(Shift s);
Shift       stringToShift(const std::string& s);

// ─────────────────────────────────────────────
//  One roster entry: who works when
// ─────────────────────────────────────────────
struct RosterEntry {
    int         staffId;
    std::string staffName;
    std::string day;          // "Monday" … "Sunday"
    Shift       shift;
};

// ─────────────────────────────────────────────
//  DutyRoster – weekly schedule manager
// ─────────────────────────────────────────────
class DutyRoster {
public:
    // Add / remove
    bool addShift(int staffId, const std::string& staffName,
                  const std::string& day, Shift shift);
    bool removeShift(int staffId, const std::string& day, Shift shift);

    // Queries
    std::vector<RosterEntry> getEntriesForDay(const std::string& day) const;
    std::vector<RosterEntry> getEntriesForStaff(int staffId) const;
    int  shiftsPerWeek(int staffId) const;
    bool hasConflict(int staffId, const std::string& day, Shift shift) const;

    // Display
    void displayWeekly() const;
    void displayForDay(const std::string& day) const;

    static const std::vector<std::string> DAYS;

private:
    std::vector<RosterEntry> entries_;
};

#endif // DUTYROSTER_H
