#include "Doctor.h"
#include <iostream>
#include <iomanip>

Doctor::Doctor(int id, const std::string& name,
               const std::string& specialty, int maxPatients)
    : id_(id), name_(name), specialty_(specialty),
      maxPatients_(maxPatients), currentLoad_(0), available_(true) {}

int         Doctor::getId()          const { return id_; }
std::string Doctor::getName()        const { return name_; }
std::string Doctor::getSpecialty()   const { return specialty_; }
int         Doctor::getMaxPatients() const { return maxPatients_; }
int         Doctor::getCurrentLoad() const { return currentLoad_; }
bool        Doctor::isAvailable()    const { return available_; }
bool        Doctor::isFull()         const { return currentLoad_ >= maxPatients_; }

void Doctor::setAvailable(bool available) { available_ = available; }

void Doctor::incrementLoad() {
    if (currentLoad_ < maxPatients_) ++currentLoad_;
}

void Doctor::decrementLoad() {
    if (currentLoad_ > 0) --currentLoad_;
}

void Doctor::display() const {
    std::string status = available_ ? (isFull() ? "FULL" : "Available") : "On Leave";
    std::cout << std::left
              << "  [D" << std::setw(3) << std::setfill('0') << id_ << std::setfill(' ') << "] "
              << std::setw(22) << name_
              << std::setw(16) << specialty_
              << "Load: " << currentLoad_ << "/" << maxPatients_
              << "  [" << status << "]\n";
}
