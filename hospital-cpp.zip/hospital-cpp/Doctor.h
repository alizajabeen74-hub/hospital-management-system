#ifndef DOCTOR_H
#define DOCTOR_H

#include <string>
#include <vector>

// ─────────────────────────────────────────────
//  Doctor – represents a hospital staff member
// ─────────────────────────────────────────────
class Doctor {
public:
    // ── Constructor
    Doctor(int id, const std::string& name,
           const std::string& specialty, int maxPatients);

    // ── Getters
    int         getId()          const;
    std::string getName()        const;
    std::string getSpecialty()   const;
    int         getMaxPatients() const;
    int         getCurrentLoad() const;
    bool        isAvailable()    const;   // true if on duty (not on leave)
    bool        isFull()         const;   // true if currentLoad >= maxPatients

    // ── Setters / mutators
    void setAvailable(bool available);
    void incrementLoad();
    void decrementLoad();

    // ── Display
    void display() const;

private:
    int         id_;
    std::string name_;
    std::string specialty_;
    int         maxPatients_;
    int         currentLoad_;
    bool        available_;       // on-duty flag
};

#endif // DOCTOR_H
