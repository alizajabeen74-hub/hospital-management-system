#include "DutyRoster.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

// ── Static member ─────────────────────────────
const std::vector<std::string> DutyRoster::DAYS = {
    "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"
};

// ── Helpers ───────────────────────────────────
std::string shiftToString(Shift s) {
    switch (s) {
        case Shift::MORNING: return "Morning";
        case Shift::EVENING: return "Evening";
        case Shift::NIGHT:   return "Night";
        default:             return "Unknown";
    }
}

Shift stringToShift(const std::string& s) {
    std::string u = s;
    for (char& c : u) c = toupper(c);
    if (u == "EVENING" || u == "2") return Shift::EVENING;
    if (u == "NIGHT"   || u == "3") return Shift::NIGHT;
    return Shift::MORNING;
}

// ── Add / Remove ──────────────────────────────
bool DutyRoster::addShift(int staffId, const std::string& staffName,
                           const std::string& day, Shift shift) {
    if (hasConflict(staffId, day, shift)) {
        std::cout << "  [!] Conflict: " << staffName
                  << " already has a " << shiftToString(shift)
                  << " shift on " << day << ".\n";
        return false;
    }
    // Max 2 shifts per day per staff
    int cnt = 0;
    for (const auto& e : entries_)
        if (e.staffId == staffId && e.day == day) ++cnt;
    if (cnt >= 2) {
        std::cout << "  [!] " << staffName
                  << " already has 2 shifts on " << day << " (max allowed).\n";
        return false;
    }
    entries_.push_back({staffId, staffName, day, shift});
    return true;
}

bool DutyRoster::removeShift(int staffId, const std::string& day, Shift shift) {
    auto it = std::find_if(entries_.begin(), entries_.end(),
        [&](const RosterEntry& e){
            return e.staffId == staffId && e.day == day && e.shift == shift;
        });
    if (it == entries_.end()) return false;
    entries_.erase(it);
    return true;
}

// ── Queries ───────────────────────────────────
bool DutyRoster::hasConflict(int staffId, const std::string& day, Shift shift) const {
    for (const auto& e : entries_)
        if (e.staffId == staffId && e.day == day && e.shift == shift) return true;
    return false;
}

std::vector<RosterEntry> DutyRoster::getEntriesForDay(const std::string& day) const {
    std::vector<RosterEntry> result;
    for (const auto& e : entries_)
        if (e.day == day) result.push_back(e);
    return result;
}

std::vector<RosterEntry> DutyRoster::getEntriesForStaff(int staffId) const {
    std::vector<RosterEntry> result;
    for (const auto& e : entries_)
        if (e.staffId == staffId) result.push_back(e);
    return result;
}

int DutyRoster::shiftsPerWeek(int staffId) const {
    int cnt = 0;
    for (const auto& e : entries_)
        if (e.staffId == staffId) ++cnt;
    return cnt;
}

// ── Display ───────────────────────────────────
void DutyRoster::displayWeekly() const {
    std::cout << "\n  ╔══════════════════════════════════════════════════════╗\n";
    std::cout <<   "  ║             WEEKLY DUTY ROSTER                      ║\n";
    std::cout <<   "  ╚══════════════════════════════════════════════════════╝\n";

    for (const auto& day : DAYS) {
        auto dayEntries = getEntriesForDay(day);
        if (dayEntries.empty()) continue;

        std::cout << "\n  ── " << day << " ──\n";
        std::cout << "    " << std::left
                  << std::setw(25) << "Staff"
                  << std::setw(12) << "Shift" << "\n";
        std::cout << "    " << std::string(37, '-') << "\n";

        for (const auto& e : dayEntries) {
            std::cout << "    " << std::left
                      << std::setw(25) << e.staffName
                      << shiftToString(e.shift) << "\n";
        }
    }
    std::cout << "\n";
}

void DutyRoster::displayForDay(const std::string& day) const {
    auto dayEntries = getEntriesForDay(day);
    std::cout << "\n  Roster for " << day << ":\n";
    if (dayEntries.empty()) {
        std::cout << "    (No shifts scheduled)\n";
        return;
    }
    for (const auto& e : dayEntries)
        std::cout << "    " << std::left << std::setw(25)
                  << e.staffName << shiftToString(e.shift) << "\n";
}
