#include "HospitalManager.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <limits>

// ─────────────────────────────────────────────
HospitalManager::HospitalManager()
    : nextDoctorId_(1), nextPatientId_(1) {}

// ── Helpers ───────────────────────────────────
Doctor* HospitalManager::findDoctor(int id) {
    for (auto& d : doctors_)
        if (d.getId() == id) return &d;
    return nullptr;
}

Patient* HospitalManager::findPatient(int id) {
    for (auto& p : patients_)
        if (p.getId() == id) return &p;
    return nullptr;
}

// ── Doctor management ─────────────────────────
void HospitalManager::addDoctor(const std::string& name,
                                 const std::string& specialty, int maxPatients) {
    doctors_.emplace_back(nextDoctorId_++, name, specialty, maxPatients);
    std::cout << "  [+] Doctor added: " << name << "\n";
}

void HospitalManager::removeDoctor(int id) {
    auto it = std::find_if(doctors_.begin(), doctors_.end(),
                           [id](const Doctor& d){ return d.getId() == id; });
    if (it == doctors_.end()) { std::cout << "  [!] Doctor not found.\n"; return; }
    std::cout << "  [-] Doctor removed: " << it->getName() << "\n";
    doctors_.erase(it);
}

void HospitalManager::listDoctors() const {
    std::cout << "\n  ╔══════════════════════════════════════════════════════╗\n";
    std::cout <<   "  ║                  DOCTOR DIRECTORY                   ║\n";
    std::cout <<   "  ╚══════════════════════════════════════════════════════╝\n";
    if (doctors_.empty()) { std::cout << "  (No doctors registered)\n\n"; return; }
    std::cout << "  " << std::left
              << std::setw(8) << "ID"
              << std::setw(22) << "Name"
              << std::setw(16) << "Specialty"
              << std::setw(14) << "Load"
              << "Status\n";
    std::cout << "  " << std::string(68, '-') << "\n";
    for (const auto& d : doctors_) d.display();
    std::cout << "\n";
}

// ── Patient management ────────────────────────
void HospitalManager::addPatient(const std::string& name, int age,
                                  const std::string& condition, Priority priority) {
    patients_.emplace_back(nextPatientId_++, name, age, condition, priority);
    std::cout << "  [+] Patient added: " << name
              << " [" << priorityToString(priority) << "]\n";
}

void HospitalManager::removePatient(int id) {
    auto it = std::find_if(patients_.begin(), patients_.end(),
                           [id](const Patient& p){ return p.getId() == id; });
    if (it == patients_.end()) { std::cout << "  [!] Patient not found.\n"; return; }
    // Release doctor load if assigned
    if (it->getAssignedDoctor() != -1) {
        Doctor* d = findDoctor(it->getAssignedDoctor());
        if (d) d->decrementLoad();
    }
    std::cout << "  [-] Patient removed: " << it->getName() << "\n";
    patients_.erase(it);
}

void HospitalManager::listPatients(bool activeOnly) const {
    std::cout << "\n  ╔══════════════════════════════════════════════════════╗\n";
    std::cout <<   "  ║                  PATIENT LIST                       ║\n";
    std::cout <<   "  ╚══════════════════════════════════════════════════════╝\n";
    std::cout << "  " << std::left
              << std::setw(8)  << "ID"
              << std::setw(20) << "Name"
              << std::setw(6)  << "Age"
              << std::setw(18) << "Condition"
              << std::setw(10) << "Priority"
              << "Status\n";
    std::cout << "  " << std::string(68, '-') << "\n";

    bool any = false;
    for (const auto& p : patients_) {
        if (activeOnly && p.getStatus() == PatientStatus::DISCHARGED) continue;
        p.display();
        any = true;
    }
    if (!any) std::cout << "  (No patients)\n";
    std::cout << "\n";
}

// ── Assignment ────────────────────────────────
bool HospitalManager::assignPatientToDoctor(int patientId, int doctorId) {
    Patient* p = findPatient(patientId);
    Doctor*  d = findDoctor(doctorId);

    if (!p) { std::cout << "  [!] Patient not found.\n"; return false; }
    if (!d) { std::cout << "  [!] Doctor not found.\n";  return false; }
    if (!d->isAvailable()) {
        std::cout << "  [!] " << d->getName() << " is on leave.\n"; return false;
    }
    if (d->isFull()) {
        std::cout << "  [!] " << d->getName()
                  << " is at full capacity (" << d->getMaxPatients() << " patients).\n";
        return false;
    }
    if (p->getStatus() == PatientStatus::ASSIGNED) {
        // Release old doctor
        Doctor* old = findDoctor(p->getAssignedDoctor());
        if (old) old->decrementLoad();
    }

    p->assignDoctor(doctorId);
    d->incrementLoad();
    std::cout << "  [✓] " << p->getName()
              << " assigned to " << d->getName() << ".\n";
    return true;
}

// Auto-assign: pick the available, non-full doctor with the least load
bool HospitalManager::autoAssign(int patientId) {
    Patient* p = findPatient(patientId);
    if (!p) { std::cout << "  [!] Patient not found.\n"; return false; }

    Doctor* best = nullptr;
    for (auto& d : doctors_) {
        if (!d.isAvailable() || d.isFull()) continue;
        if (!best || d.getCurrentLoad() < best->getCurrentLoad())
            best = &d;
    }
    if (!best) {
        std::cout << "  [!] No available doctor found for auto-assignment.\n";
        return false;
    }
    return assignPatientToDoctor(patientId, best->getId());
}

void HospitalManager::dischargePatient(int patientId) {
    Patient* p = findPatient(patientId);
    if (!p) { std::cout << "  [!] Patient not found.\n"; return; }
    if (p->getAssignedDoctor() != -1) {
        Doctor* d = findDoctor(p->getAssignedDoctor());
        if (d) d->decrementLoad();
    }
    p->discharge();
    std::cout << "  [✓] " << p->getName() << " discharged.\n";
}

void HospitalManager::listUnassigned() const {
    std::cout << "\n  Unassigned / Waiting patients:\n";
    bool any = false;
    for (const auto& p : patients_) {
        if (p.getStatus() == PatientStatus::WAITING) {
            p.display();
            any = true;
        }
    }
    if (!any) std::cout << "  (None — all patients are assigned)\n";
    std::cout << "\n";
}

// ── Duty Roster ───────────────────────────────
DutyRoster& HospitalManager::getRoster() { return roster_; }

void HospitalManager::addShift(int staffId, const std::string& staffName,
                                const std::string& day, const std::string& shift) {
    bool ok = roster_.addShift(staffId, staffName, day, stringToShift(shift));
    if (ok) std::cout << "  [+] Shift added: " << staffName
                      << " — " << day << " " << shift << "\n";
}

void HospitalManager::removeShift(int staffId, const std::string& day,
                                   const std::string& shift) {
    bool ok = roster_.removeShift(staffId, day, stringToShift(shift));
    std::cout << (ok ? "  [-] Shift removed.\n" : "  [!] Shift not found.\n");
}

// ── Dashboard ─────────────────────────────────
void HospitalManager::showDashboard() const {
    int total    = 0, waiting = 0, assigned = 0, avail = 0;
    for (const auto& p : patients_) {
        if (p.getStatus() == PatientStatus::DISCHARGED) continue;
        ++total;
        if (p.getStatus() == PatientStatus::WAITING)  ++waiting;
        if (p.getStatus() == PatientStatus::ASSIGNED) ++assigned;
    }
    for (const auto& d : doctors_)
        if (d.isAvailable()) ++avail;

    std::cout << "\n  ╔══════════════════════════════════════════════════════╗\n";
    std::cout <<   "  ║              HOSPITAL DASHBOARD                     ║\n";
    std::cout <<   "  ╠══════════════════════════════════════════════════════╣\n";
    std::cout << "  ║  Total Patients   : " << std::left << std::setw(32) << total       << "║\n";
    std::cout << "  ║  Waiting          : " << std::setw(32) << waiting                  << "║\n";
    std::cout << "  ║  Assigned         : " << std::setw(32) << assigned                 << "║\n";
    std::cout << "  ║  Doctors Available: " << std::setw(32)
              << (std::to_string(avail) + "/" + std::to_string(doctors_.size()))          << "║\n";
    std::cout <<   "  ╚══════════════════════════════════════════════════════╝\n\n";

    // Critical unassigned warning
    for (const auto& p : patients_) {
        if (p.getPriority() == Priority::CRITICAL &&
            p.getStatus()   == PatientStatus::WAITING) {
            std::cout << "  [⚠] CRITICAL patient unassigned: "
                      << p.getName() << " — " << p.getCondition() << "\n";
        }
    }
}

void HospitalManager::showWorkload() const {
    std::cout << "\n  Doctor Workload:\n";
    std::cout << "  " << std::left
              << std::setw(22) << "Name"
              << std::setw(16) << "Specialty"
              << "Load\n";
    std::cout << "  " << std::string(50, '-') << "\n";
    for (const auto& d : doctors_) {
        int load = d.getCurrentLoad(), mx = d.getMaxPatients();
        int bars = (mx > 0) ? (load * 20 / mx) : 0;
        std::string bar(bars, '#');
        bar += std::string(20 - bars, '.');
        std::cout << "  " << std::left
                  << std::setw(22) << d.getName()
                  << std::setw(16) << d.getSpecialty()
                  << "[" << bar << "] "
                  << load << "/" << mx
                  << (d.isFull() ? "  FULL" : "")
                  << "\n";
    }
    std::cout << "\n";
}

// ── Sample Data ───────────────────────────────
void HospitalManager::loadSampleData() {
    // Doctors
    addDoctor("Dr. Ayesha Khan",   "Cardiology",   8);
    addDoctor("Dr. Omar Farooq",   "Neurology",    6);
    addDoctor("Dr. Sara Malik",    "Orthopedics",  7);
    addDoctor("Dr. Bilal Ahmed",   "Pediatrics",   5);
    addDoctor("Dr. Nadia Hussain", "General",     10);

    // Mark D004 on leave
    Doctor* onLeave = findDoctor(4);
    if (onLeave) onLeave->setAvailable(false);

    // Patients
    addPatient("Ahmed Raza",    55, "Chest Pain",   Priority::CRITICAL);
    addPatient("Zainab Noor",   32, "Migraine",     Priority::MODERATE);
    addPatient("Kamran Iqbal",  45, "Fracture",     Priority::MODERATE);
    addPatient("Sana Riaz",      8, "Fever",        Priority::STABLE);
    addPatient("Farhan Malik",  67, "Hypertension", Priority::CRITICAL);
    addPatient("Amna Tariq",    25, "Appendicitis", Priority::CRITICAL);
    addPatient("Yasir Shah",    38, "Back Pain",    Priority::STABLE);

    // Assignments
    assignPatientToDoctor(1, 1); // Ahmed  -> Dr. Ayesha
    assignPatientToDoctor(2, 2); // Zainab -> Dr. Omar
    assignPatientToDoctor(4, 5); // Sana   -> Dr. Nadia
    assignPatientToDoctor(6, 5); // Amna   -> Dr. Nadia

    // Roster
    addShift(1, "Dr. Ayesha Khan",   "Monday",    "Morning");
    addShift(1, "Dr. Ayesha Khan",   "Tuesday",   "Morning");
    addShift(1, "Dr. Ayesha Khan",   "Wednesday", "Morning");
    addShift(2, "Dr. Omar Farooq",   "Monday",    "Morning");
    addShift(2, "Dr. Omar Farooq",   "Thursday",  "Morning");
    addShift(3, "Dr. Sara Malik",    "Monday",    "Evening");
    addShift(3, "Dr. Sara Malik",    "Wednesday", "Evening");
    addShift(3, "Dr. Sara Malik",    "Friday",    "Evening");
    addShift(5, "Dr. Nadia Hussain", "Monday",    "Morning");
    addShift(5, "Dr. Nadia Hussain", "Tuesday",   "Morning");
    addShift(5, "Dr. Nadia Hussain", "Friday",    "Morning");

    std::cout << "\n  [✓] Sample data loaded successfully.\n";
}
