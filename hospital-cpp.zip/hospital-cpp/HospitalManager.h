#ifndef HOSPITALMANAGER_H
#define HOSPITALMANAGER_H

#include "Doctor.h"
#include "Patient.h"
#include "DutyRoster.h"
#include <vector>
#include <memory>

// ─────────────────────────────────────────────
//  HospitalManager – central controller
//  Manages doctors, patients, and the roster.
// ─────────────────────────────────────────────
class HospitalManager {
public:
    HospitalManager();

    // ── Doctor management
    void addDoctor(const std::string& name, const std::string& specialty, int maxPatients);
    void removeDoctor(int doctorId);
    void listDoctors() const;
    Doctor* findDoctor(int doctorId);

    // ── Patient management
    void addPatient(const std::string& name, int age,
                    const std::string& condition, Priority priority);
    void removePatient(int patientId);
    void listPatients(bool activeOnly = true) const;
    Patient* findPatient(int patientId);

    // ── Assignment
    bool assignPatientToDoctor(int patientId, int doctorId);
    bool autoAssign(int patientId);   // assign to least-loaded available doctor
    void dischargePatient(int patientId);
    void listUnassigned() const;

    // ── Duty Roster
    DutyRoster& getRoster();
    void addShift(int staffId, const std::string& staffName,
                  const std::string& day, const std::string& shift);
    void removeShift(int staffId, const std::string& day, const std::string& shift);

    // ── Dashboard / stats
    void showDashboard() const;
    void showWorkload() const;

    // ── Sample data
    void loadSampleData();

private:
    std::vector<Doctor>  doctors_;
    std::vector<Patient> patients_;
    DutyRoster           roster_;

    int nextDoctorId_;
    int nextPatientId_;
};

#endif // HOSPITALMANAGER_H
