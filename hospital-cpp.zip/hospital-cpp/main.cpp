// ═══════════════════════════════════════════════════════════
//   MediAssign — Hospital Staff & Patient Management System
//   Language : C++17
//   Author   : Hospital Management Project
// ═══════════════════════════════════════════════════════════

#include "HospitalManager.h"
#include <iostream>
#include <string>
#include <limits>

// ── Utility: clear input buffer ───────────────
static void clearInput() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

static int getInt(const std::string& prompt) {
    int v;
    std::cout << prompt;
    while (!(std::cin >> v)) { clearInput(); std::cout << "  Enter a number: "; }
    clearInput();
    return v;
}

static std::string getString(const std::string& prompt) {
    std::string s;
    std::cout << prompt;
    std::getline(std::cin, s);
    return s;
}

// ─────────────────────────────────────────────
//  Sub-menus
// ─────────────────────────────────────────────
void menuPatients(HospitalManager& hm) {
    int choice;
    do {
        std::cout << "\n  ┌─ PATIENT MANAGEMENT ─────────────────┐\n";
        std::cout <<   "  │  1. List active patients              │\n";
        std::cout <<   "  │  2. Add new patient                   │\n";
        std::cout <<   "  │  3. Assign patient to doctor          │\n";
        std::cout <<   "  │  4. Auto-assign (least-loaded doctor) │\n";
        std::cout <<   "  │  5. Discharge patient                 │\n";
        std::cout <<   "  │  6. List unassigned patients          │\n";
        std::cout <<   "  │  7. Remove patient record             │\n";
        std::cout <<   "  │  0. Back                              │\n";
        std::cout <<   "  └───────────────────────────────────────┘\n";
        choice = getInt("  Choice: ");

        if (choice == 1) {
            hm.listPatients();
        } else if (choice == 2) {
            std::string name = getString("  Patient name   : ");
            int age = getInt("  Age            : ");
            std::string cond = getString("  Condition       : ");
            std::cout << "  Priority (1=Stable, 2=Moderate, 3=Critical): ";
            int pri; std::cin >> pri; clearInput();
            Priority p = (pri == 3) ? Priority::CRITICAL
                       : (pri == 2) ? Priority::MODERATE
                                    : Priority::STABLE;
            hm.addPatient(name, age, cond, p);
        } else if (choice == 3) {
            hm.listPatients();
            hm.listDoctors();
            int pid = getInt("  Patient ID : ");
            int did = getInt("  Doctor ID  : ");
            hm.assignPatientToDoctor(pid, did);
        } else if (choice == 4) {
            hm.listUnassigned();
            int pid = getInt("  Patient ID to auto-assign: ");
            hm.autoAssign(pid);
        } else if (choice == 5) {
            hm.listPatients();
            int pid = getInt("  Patient ID to discharge: ");
            hm.dischargePatient(pid);
        } else if (choice == 6) {
            hm.listUnassigned();
        } else if (choice == 7) {
            hm.listPatients();
            int pid = getInt("  Patient ID to remove: ");
            hm.removePatient(pid);
        }
    } while (choice != 0);
}

void menuDoctors(HospitalManager& hm) {
    int choice;
    do {
        std::cout << "\n  ┌─ DOCTOR / STAFF MANAGEMENT ──────────┐\n";
        std::cout <<   "  │  1. List all doctors                  │\n";
        std::cout <<   "  │  2. Add new doctor                    │\n";
        std::cout <<   "  │  3. Remove doctor                     │\n";
        std::cout <<   "  │  4. Show workload chart               │\n";
        std::cout <<   "  │  0. Back                              │\n";
        std::cout <<   "  └───────────────────────────────────────┘\n";
        choice = getInt("  Choice: ");

        if (choice == 1) {
            hm.listDoctors();
        } else if (choice == 2) {
            std::string name = getString("  Doctor name  : ");
            std::string spec = getString("  Specialty    : ");
            int mx = getInt("  Max patients : ");
            hm.addDoctor(name, spec, mx);
        } else if (choice == 3) {
            hm.listDoctors();
            int id = getInt("  Doctor ID to remove: ");
            hm.removeDoctor(id);
        } else if (choice == 4) {
            hm.showWorkload();
        }
    } while (choice != 0);
}

void menuRoster(HospitalManager& hm) {
    int choice;
    do {
        std::cout << "\n  ┌─ DUTY ROSTER ─────────────────────────┐\n";
        std::cout <<   "  │  1. View full weekly roster           │\n";
        std::cout <<   "  │  2. View roster for a specific day    │\n";
        std::cout <<   "  │  3. Add shift                         │\n";
        std::cout <<   "  │  4. Remove shift                      │\n";
        std::cout <<   "  │  0. Back                              │\n";
        std::cout <<   "  └───────────────────────────────────────┘\n";
        choice = getInt("  Choice: ");

        if (choice == 1) {
            hm.getRoster().displayWeekly();
        } else if (choice == 2) {
            std::string day = getString("  Day (e.g. Monday): ");
            hm.getRoster().displayForDay(day);
        } else if (choice == 3) {
            hm.listDoctors();
            int id = getInt("  Staff ID       : ");
            std::string name = getString("  Staff name      : ");
            std::string day  = getString("  Day             : ");
            std::cout << "  Shift (Morning/Evening/Night): ";
            std::string shift; std::getline(std::cin, shift);
            hm.addShift(id, name, day, shift);
        } else if (choice == 4) {
            int id = getInt("  Staff ID  : ");
            std::string day   = getString("  Day       : ");
            std::string shift = getString("  Shift     : ");
            hm.removeShift(id, day, shift);
        }
    } while (choice != 0);
}

// ─────────────────────────────────────────────
//  Main
// ─────────────────────────────────────────────
int main() {
    std::cout << "\n";
    std::cout << "  ███╗   ███╗███████╗██████╗ ██╗ █████╗ ███████╗███████╗██╗ ██████╗ ███╗\n";
    std::cout << "  ████╗ ████║██╔════╝██╔══██╗██║██╔══██╗██╔════╝██╔════╝██║██╔════╝ ███║\n";
    std::cout << "  ██╔████╔██║█████╗  ██║  ██║██║███████║███████╗███████╗██║██║  ███╗███║\n";
    std::cout << "  ██║╚██╔╝██║██╔══╝  ██║  ██║██║██╔══██║╚════██║╚════██║██║██║   ██║╚══╝\n";
    std::cout << "  ██║ ╚═╝ ██║███████╗██████╔╝██║██║  ██║███████║███████║██║╚██████╔╝███╗\n";
    std::cout << "  ╚═╝     ╚═╝╚══════╝╚═════╝ ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝ ╚═════╝ ╚══╝\n";
    std::cout << "\n         Hospital Staff & Patient Management System  (C++)\n\n";

    HospitalManager hm;

    std::cout << "  Load sample data? (y/n): ";
    char c; std::cin >> c; clearInput();
    if (c == 'y' || c == 'Y') hm.loadSampleData();

    int choice;
    do {
        std::cout << "\n  ╔═══════════════════════════════════╗\n";
        std::cout <<   "  ║        MAIN MENU                  ║\n";
        std::cout <<   "  ╠═══════════════════════════════════╣\n";
        std::cout <<   "  ║  1. Dashboard / Overview          ║\n";
        std::cout <<   "  ║  2. Patient Management            ║\n";
        std::cout <<   "  ║  3. Doctor / Staff Management     ║\n";
        std::cout <<   "  ║  4. Duty Roster                   ║\n";
        std::cout <<   "  ║  0. Exit                          ║\n";
        std::cout <<   "  ╚═══════════════════════════════════╝\n";
        choice = getInt("  Choice: ");

        switch (choice) {
            case 1: hm.showDashboard(); break;
            case 2: menuPatients(hm);   break;
            case 3: menuDoctors(hm);    break;
            case 4: menuRoster(hm);     break;
            case 0: std::cout << "\n  Goodbye!\n\n"; break;
            default: std::cout << "  [!] Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}
