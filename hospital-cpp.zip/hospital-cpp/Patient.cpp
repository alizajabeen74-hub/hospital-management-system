#include "Patient.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

// ── Helpers ──────────────────────────────────
std::string priorityToString(Priority p) {
    switch (p) {
        case Priority::CRITICAL: return "CRITICAL";
        case Priority::MODERATE: return "MODERATE";
        case Priority::STABLE:   return "STABLE";
        default:                 return "UNKNOWN";
    }
}

Priority stringToPriority(const std::string& s) {
    std::string u = s;
    for (char& c : u) c = toupper(c);
    if (u == "CRITICAL" || u == "3") return Priority::CRITICAL;
    if (u == "MODERATE" || u == "2") return Priority::MODERATE;
    return Priority::STABLE;
}

std::string statusToString(PatientStatus s) {
    switch (s) {
        case PatientStatus::WAITING:    return "Waiting";
        case PatientStatus::ASSIGNED:   return "Assigned";
        case PatientStatus::DISCHARGED: return "Discharged";
        default:                        return "Unknown";
    }
}

// ── Patient ──────────────────────────────────
Patient::Patient(int id, const std::string& name, int age,
                 const std::string& condition, Priority priority)
    : id_(id), name_(name), age_(age), condition_(condition),
      priority_(priority), status_(PatientStatus::WAITING),
      assignedDoctorId_(-1) {}

int           Patient::getId()             const { return id_; }
std::string   Patient::getName()           const { return name_; }
int           Patient::getAge()            const { return age_; }
std::string   Patient::getCondition()      const { return condition_; }
Priority      Patient::getPriority()       const { return priority_; }
PatientStatus Patient::getStatus()         const { return status_; }
int           Patient::getAssignedDoctor() const { return assignedDoctorId_; }

void Patient::assignDoctor(int doctorId) {
    assignedDoctorId_ = doctorId;
    status_ = PatientStatus::ASSIGNED;
}

void Patient::discharge() {
    status_ = PatientStatus::DISCHARGED;
    assignedDoctorId_ = -1;
}

void Patient::display() const {
    std::cout << std::left
              << "  [P" << std::setw(3) << std::setfill('0') << id_ << std::setfill(' ') << "] "
              << std::setw(20) << name_
              << "Age:" << std::setw(5) << age_
              << std::setw(18) << condition_
              << std::setw(10) << priorityToString(priority_)
              << statusToString(status_) << "\n";
}
