#ifndef PATIENT_H
#define PATIENT_H

#include <string>

// ─────────────────────────────────────────────
//  Priority levels (higher = more urgent)
// ─────────────────────────────────────────────
enum class Priority {
    STABLE   = 1,
    MODERATE = 2,
    CRITICAL = 3
};

std::string priorityToString(Priority p);
Priority    stringToPriority(const std::string& s);

// ─────────────────────────────────────────────
//  Patient status
// ─────────────────────────────────────────────
enum class PatientStatus { WAITING, ASSIGNED, DISCHARGED };

std::string statusToString(PatientStatus s);

// ─────────────────────────────────────────────
//  Patient
// ─────────────────────────────────────────────
class Patient {
public:
    Patient(int id, const std::string& name, int age,
            const std::string& condition, Priority priority);

    // ── Getters
    int           getId()            const;
    std::string   getName()          const;
    int           getAge()           const;
    std::string   getCondition()     const;
    Priority      getPriority()      const;
    PatientStatus getStatus()        const;
    int           getAssignedDoctor()const;   // -1 if none

    // ── Mutators
    void assignDoctor(int doctorId);
    void discharge();

    // ── Display
    void display() const;

private:
    int           id_;
    std::string   name_;
    int           age_;
    std::string   condition_;
    Priority      priority_;
    PatientStatus status_;
    int           assignedDoctorId_;
};

#endif // PATIENT_H
