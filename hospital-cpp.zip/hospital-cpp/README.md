# 🏥 MediAssign — Hospital Management System (C++)

A console-based C++ application that solves the real-world problem of **patient-to-doctor assignment** and **duty roster scheduling** in hospitals with limited staff.

---

## 🚩 Problem Statement

Hospitals face critical challenges:
- Manual patient assignment causing uneven doctor workload
- No capacity enforcement leading to overloaded doctors
- Unorganized duty rosters causing shift conflicts and staff burnout
- No visibility into who is available at any given time

---

## ✨ Features

### 👨‍⚕️ Patient Management
- Add / remove patients with name, age, condition, priority
- Priority levels: **Critical**, **Moderate**, **Stable**
- Assign patient to a specific doctor (with capacity check)
- **Auto-assign** to the least-loaded available doctor
- Discharge patients and free up doctor slots
- View all unassigned/waiting patients

### 🩺 Doctor Management
- Add / remove doctors with specialty and max patient capacity
- Mark doctors as on-leave
- Visual workload bar for each doctor
- Capacity enforcement — cannot over-assign

### 🗓️ Duty Roster
- Add weekly shifts (Morning / Evening / Night)
- Conflict detection (blocks duplicate shifts)
- Max 2 shifts per staff per day enforced
- View full weekly roster or filter by day
- Remove shifts

### 📊 Dashboard
- Summary: total patients, waiting, assigned, available doctors
- Critical unassigned patient warnings

---

## 🏗️ Project Structure

```
hospital-cpp/
├── main.cpp              # Entry point + menus
├── Doctor.h / .cpp       # Doctor class
├── Patient.h / .cpp      # Patient class + Priority/Status enums
├── DutyRoster.h / .cpp   # Roster manager + conflict detection
├── HospitalManager.h/.cpp# Central controller (facade)
├── Makefile              # Build script
└── README.md
```

### Class Diagram (simplified)
```
HospitalManager
  ├── vector<Doctor>        — staff registry
  ├── vector<Patient>       — patient registry
  └── DutyRoster            — weekly schedule
        └── vector<RosterEntry>
```

---

## 🔧 Build & Run

### Requirements
- g++ with C++17 support
- GNU Make (optional)

### Using Makefile
```bash
make          # compile
make run      # compile + run
make clean    # remove build files
```

### Manual compile
```bash
g++ -std=c++17 -Wall -O2 -o hospital \
    main.cpp Doctor.cpp Patient.cpp DutyRoster.cpp HospitalManager.cpp
./hospital
```

### Windows (MinGW)
```bash
g++ -std=c++17 -o hospital.exe main.cpp Doctor.cpp Patient.cpp DutyRoster.cpp HospitalManager.cpp
hospital.exe
```

---

## 📸 Sample Session

```
  MAIN MENU
  1. Dashboard / Overview
  2. Patient Management
  3. Doctor / Staff Management
  4. Duty Roster
  0. Exit

  Choice: 1

  ╔══════════════════════════════════════════════╗
  ║              HOSPITAL DASHBOARD             ║
  ╠══════════════════════════════════════════════╣
  ║  Total Patients   : 7                       ║
  ║  Waiting          : 3                       ║
  ║  Assigned         : 4                       ║
  ║  Doctors Available: 4/5                     ║
  ╚══════════════════════════════════════════════╝

  [⚠] CRITICAL patient unassigned: Farhan Malik — Hypertension
```

---

## 🔮 Possible Extensions

- File I/O (save/load data from CSV or binary files)
- Sorting patients by priority using a priority queue
- Notification system for unassigned critical patients
- GUI using Qt or wxWidgets
- Database backend with SQLite

---

## 📄 License

MIT — free to use, modify, and distribute.
